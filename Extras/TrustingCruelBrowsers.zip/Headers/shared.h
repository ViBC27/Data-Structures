/* ->
// Data Structure: Shared
// Authors: 
-> Vitor Barcelos de Cerqueira
-> Ramon Basto Callado
-> Daniel melo de lima
<- */

#ifndef Shared_H
#define Shared_H
#include <stdio.h>

FILE* OpenInputFile(char *inputFile);

#endif